# 파일명: hybrid_alligator_atr_with_sell.py
from freqtrade.strategy import IStrategy
from freqtrade.strategy.parameters import RealParameter, IntParameter

import talib.abstract as ta
import pandas as pd
from pandas import DataFrame


class HybridAlligatorATRStrategy(IStrategy):
    """
    안정적인 버전: Alligator + ATR 브레이크아웃 + Volume/Volatility + 최근 고점 돌파 필터
    하이퍼옵트 대상: buy 파라미터 + stoploss 포함 (최신 Freqtrade 호환 완전 지원)
    """

    timeframe = '5m'
    startup_candle_count = 50

    # ── ROI / 손절매 설정 ─────────────────────────────────────────────
    minimal_roi = {"0": 0.02, "10": 0.01, "30": 0}

    # 고정 stoploss (strategy.stoploss 는 항상 float 이어야 함)
    stoploss = -0.05

    # 하이퍼옵트용 stoploss 파라미터 (별도 선언)
    stoploss_param = RealParameter(-0.10, -0.01, default=-0.05,
                                   space='sell', optimize=True, load=True)

    trailing_stop = True
    trailing_stop_positive = 0.03
    trailing_stop_positive_offset = 0.05
    # ────────────────────────────────────────────────────────────────

    process_only_new_candles = True
    use_custom_stoploss = True  # custom_stoploss 사용
    can_long = True
    can_short = False

    # ── Hyperopt 대상 파라미터 ──────────────────────────────────────
    atr_period      = IntParameter(8, 21,  default=14, space='buy', optimize=True, load=True)
    vol_multiplier  = RealParameter(1.0, 3.0, default=1.2,  space='buy', optimize=True, load=True)
    volat_threshold = RealParameter(0.003,0.02,default=0.005,space='buy', optimize=True, load=True)
    high_lookback   = IntParameter(1, 7,   default=3,   space='buy', optimize=True, load=True)
    # ────────────────────────────────────────────────────────────────

    # ── Hyperopt 결과값 반영 ────────────────────────────────────────
    buy_params = {
        "atr_period":     18,
        "high_lookback":   7,
        "vol_multiplier":  1.68035,
        "volat_threshold": 0.00928,
    }

    sell_params = {
        "stoploss_param": -0.04678,
    }

    def populate_indicators(self, dataframe: DataFrame,
                            metadata: dict) -> DataFrame:
        hl2 = (dataframe['high'] + dataframe['low']) / 2
        dataframe['jaw'] = pd.Series(
            ta.EMA(hl2, timeperiod=13), index=dataframe.index
        ).shift(8)
        dataframe['teeth'] = pd.Series(
            ta.EMA(hl2, timeperiod=8), index=dataframe.index
        ).shift(5)
        dataframe['lips'] = pd.Series(
            ta.EMA(hl2, timeperiod=5), index=dataframe.index
        ).shift(3)

        dataframe['adx'] = ta.ADX(dataframe, timeperiod=14)
        dataframe['plusdi'] = ta.PLUS_DI(dataframe, timeperiod=14)
        dataframe['minusdi'] = ta.MINUS_DI(dataframe, timeperiod=14)

        dataframe['atr'] = ta.ATR(
            dataframe, timeperiod=int(self.atr_period.value)
        )
        dataframe['vol_ma'] = dataframe['volume'].rolling(10).mean()

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame,
                             metadata: dict) -> DataFrame:
        if dataframe.empty:
            return dataframe

        breakout      = dataframe['close'] > (dataframe['close'].shift(1) + dataframe['atr'])
        volume_ok     = dataframe['volume'] > dataframe['vol_ma'] * self.vol_multiplier.value
        volatility_ok = dataframe['atr'] > (dataframe['close'] * self.volat_threshold.value)
        recent_high   = dataframe['high'].rolling(int(self.high_lookback.value)).max().shift(1)
        high_breakout = dataframe['close'] > recent_high
        # ← ADX 필터: 추세 강도(>25) 구간만 진입
        trend_ok      = dataframe['adx'] > 25

        entry_signal = breakout \
                     & volume_ok \
                     & volatility_ok \
                     & high_breakout \
                     & trend_ok
        dataframe.loc[entry_signal, 'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame,
                            metadata: dict) -> DataFrame:
        dataframe.loc[
            dataframe['lips'] < dataframe['teeth'],
            'exit_long'
        ] = 1
        return dataframe
