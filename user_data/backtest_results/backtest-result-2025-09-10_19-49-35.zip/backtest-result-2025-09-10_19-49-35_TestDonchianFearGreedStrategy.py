from freqtrade.strategy.interface import IStrategy
from pandas import DataFrame
import pandas as pd
from pathlib import Path
import sys

# === collectors 경로 추가 ===
BASE_DIR = Path(__file__).resolve().parents[1]              # /freqtrade/user_data
COLLECTORS_DIR = BASE_DIR / "collectors"
if str(COLLECTORS_DIR) not in sys.path:
    sys.path.insert(0, str(COLLECTORS_DIR))

from fear_greed import FearGreedCollector
try:
    from freqtrade.strategy import IntParameter
    HAVE_HYPER = True
except Exception:
    HAVE_HYPER = False


class TestDonchianFearGreedStrategy(IStrategy):
    timeframe = "5m"
    can_short = False

    minimal_roi = {"0": 10}   # 테스트용
    stoploss = -0.99          # 테스트용

    if HAVE_HYPER:
        buy_fg_threshold = IntParameter(30, 80, default=55, space='buy')
    else:
        buy_fg_threshold = None

    plot_config = {
        "main_plot": {"donchian_high": {"color": "orange"}},
        "subplots": {"FG": {"fg_value": {"color": "green"}}},
    }

    debug = True

    @staticmethod
    def _pair_folder(pair: str) -> str:
        return pair.replace("/", "_")  # BTC/USDT -> BTC_USDT

    def _load_fg_series(self, pair_folder: str) -> pd.Series:
        fg = FearGreedCollector(mode="backtest", data_dir=str(COLLECTORS_DIR / "data"))
        data = fg._load_jsonl(pair_folder, "fear_greed")  # {ts:int -> {...}}
        if not data:
            return pd.Series(dtype=float)
        ts = sorted(data.keys())
        vals = [float(data[t]["value"]) for t in ts]
        s = pd.Series(vals, index=pd.to_datetime(ts, unit="s", utc=True), name="fg_value")
        return s.sort_index()

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Donchian high(20)
        dataframe["donchian_high"] = dataframe["high"].rolling(20).max()

        # FearGreed 병합 (UTC tz-aware ↔ tz-aware)
        pair_folder = self._pair_folder(metadata["pair"])
        fg_series = self._load_fg_series(pair_folder)

        if not fg_series.empty:
            df = dataframe.copy()
            # ✅ tz-aware로 변환 (values 쓰지 말 것!)
            df["_dt"] = pd.to_datetime(df["date"], utc=True)

            merged = pd.merge_asof(
                df.sort_values("_dt"),
                fg_series.to_frame().sort_index(),
                left_on="_dt",          # tz-aware
                right_index=True,       # tz-aware
                direction="backward",
            )
            dataframe["fg_value"] = merged["fg_value"].ffill().fillna(50.0)
        else:
            dataframe["fg_value"] = 50.0

        if self.debug:
            tail = dataframe[["date", "close", "donchian_high", "fg_value"]].tail(3)
            print("[DEBUG][FG merge tail]\n", tail.to_string(index=False))

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe["enter_long"] = 0

        cond_break = dataframe["close"] > dataframe["donchian_high"].shift(1)

        thr = 55
        if self.buy_fg_threshold is not None:
            try:
                thr = int(getattr(self, "buy_fg_threshold").value)
            except Exception:
                thr = 55

        cond_fg = dataframe["fg_value"] >= thr
        cond = cond_break & cond_fg

        dataframe.loc[cond, "enter_long"] = 1

        if self.debug:
            print(f"[DEBUG] FG threshold={thr}, entries={int(cond.sum())}")

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe["exit_long"] = 0
        return dataframe
