# 파일명: hybrid_alligator_atr_relaxed.py
from freqtrade.strategy import IStrategy
from freqtrade.strategy.parameters import RealParameter, IntParameter
import talib.abstract as ta
import pandas as pd
from pandas import DataFrame

class HybridAlligatorATRRelaxedStrategy(IStrategy):
    timeframe = '5m'
    startup_candle_count = 50
    #  ATR 기반 동적 손절 계수 (ATR * multiplier 비율로 손절)
    sl_atr_multiplier = RealParameter(
        0.5, 3.0,              # 최소 0.5배, 최대 3.0배
        default=1.5,           # 기본값 1.5
        space='sell',          # 매도 공간에서 최적화
        optimize=True,         # Hyperopt 적용
        load=True              # 저장된 값 불러오기
    )
    minimal_roi = {"0": 0.02, "10": 0.01, "30": 0}
    stoploss = -0.05
    stoploss_param = RealParameter(-0.10, -0.01, default=-0.05,
                                   space='sell', optimize=True, load=True)

    trailing_stop = True
    trailing_stop_positive = 0.03
    trailing_stop_positive_offset = 0.05

    process_only_new_candles = True
    use_custom_stoploss = True
    can_long = True
    can_short = False

    atr_period      = IntParameter(8, 21,  default=14, space='buy', optimize=True, load=True)
    vol_multiplier  = RealParameter(1.0, 3.0, default=1.2,  space='buy', optimize=True, load=True)
    volat_threshold = RealParameter(0.003,0.02, default=0.005,space='buy', optimize=True, load=True)
    high_lookback   = IntParameter(1, 7,   default=3,   space='buy', optimize=True, load=True)

    buy_params = {
        "atr_period":     18,
        "high_lookback":   7,
        "vol_multiplier":  1.68035,
        "volat_threshold": 0.00928,
    }
    sell_params = {
        "stoploss_param": -0.04678,
    }

    def custom_stoploss(self, pair, trade, current_time, current_rate, current_profit, **kwargs) -> float:
        # 1) 최신 ATR 값 가져오기
        df = self.dp.get_pair_dataframe(pair=pair, timeframe=self.timeframe)
        atr = df['atr'].iloc[-1]

        # 2) dynamic_stop = ATR * multiplier 비율 → 가격 대비 비율로 변환
        dynamic_stop = (atr * self.sl_atr_multiplier.value) / current_rate

        # 3) 음수 값으로 반환 (예: -0.02 → -2% 손절)
        return -dynamic_stop

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        hl2 = (dataframe['high'] + dataframe['low']) / 2
        dataframe['jaw']   = pd.Series(ta.EMA(hl2, timeperiod=13), index=dataframe.index).shift(8)
        dataframe['teeth'] = pd.Series(ta.EMA(hl2, timeperiod=8),  index=dataframe.index).shift(5)
        dataframe['lips']  = pd.Series(ta.EMA(hl2, timeperiod=5),  index=dataframe.index).shift(3)

        dataframe['adx']     = ta.ADX(dataframe, timeperiod=14)
        dataframe['plusdi']  = ta.PLUS_DI(dataframe, timeperiod=14)
        dataframe['minusdi'] = ta.MINUS_DI(dataframe, timeperiod=14)

        dataframe['atr']    = ta.ATR(dataframe, timeperiod=int(self.atr_period.value))
        dataframe['vol_ma'] = dataframe['volume'].rolling(10).mean()
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        if dataframe.empty:
            return dataframe

        # ATR 브레이크아웃
                # → 브레이크아웃 조건 완화: 0.5×ATR
        breakout = dataframe['close'] > (dataframe['close'].shift(1) + dataframe['atr'] * 0.5)

        # Volume 필터
        # → 볼륨 필터 완화: vol_multiplier를 1.0으로 고정
        volume_ok = dataframe['volume'] > dataframe['vol_ma'] * 1.0

        # Volatility 필터
        # → 변동성 필터 완화: threshold를 0.003으로 고정
        volatility_ok = dataframe['atr'] > (dataframe['close'] * 0.003)

        # → High-breakout 필터를 잠시 제거합니다.
        # recent_high = dataframe['high'].rolling(int(self.high_lookback.value)).max().shift(1)
        # high_breakout = dataframe['close'] > recent_high

        entry_signal = breakout & volume_ok & volatility_ok
        dataframe.loc[entry_signal, 'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[dataframe['lips'] < dataframe['teeth'], 'exit_long'] = 1
        return dataframe
