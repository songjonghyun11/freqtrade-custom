# -*- coding: utf-8 -*-
from typing import Dict, Any, List
from pathlib import Path
import json
import pandas as pd

from freqtrade.strategy.interface import IStrategy
from freqtrade.strategy import IntParameter, DecimalParameter


class TestDonchianFearGreedStrategy(IStrategy):
    """
    Donchian 돌파 + 거래량 배수 + (옵션) Fear&Greed 게이트
    - 룩어헤드 방지: Donchian 상단은 shift(1), merge_asof(backward)
    - 하이퍼옵트: buy/roi/stoploss 공간만 사용 (모든 파라미터 .value)
    """
    timeframe = "5m"
    startup_candle_count = 120

    # ---- 하이퍼옵트/실행 파라미터(.value 필수) ----
    use_fg = IntParameter(0, 1, default=1, space="buy", optimize=True)                 # FG 게이트 사용 여부
    buy_fg_threshold = IntParameter(45, 60, default=50, space="buy", optimize=True)    # FG 임계값
    buy_vol_mult = DecimalParameter(1.00, 2.00, default=1.20, decimals=2,
                                    space="buy", optimize=True)                        # 거래량 배수
    buy_dc_period = IntParameter(12, 30, default=20, space="buy", optimize=True)       # Donchian 기간

    # ROI/SL(필요 시 하이퍼옵트에서 조정)
    minimal_roi = {"0": 0.05, "60": 0.02, "240": 0.0}
    stoploss = -0.08

    # ---------------- 내부 유틸 ----------------
    @staticmethod
    def _pair_safe(pair: str) -> str:
        # 'BTC/USDT' -> 'BTC_USDT'
        return pair.replace("/", "_")

    def _candidate_fg_paths(self, pair: str) -> List[Path]:
        userdir = Path(self.config.get("user_data_dir", "/freqtrade/user_data"))
        safe = self._pair_safe(pair)
        return [
            userdir / "collectors" / "data" / safe / "fear_greed.json",
            userdir / "collectors" / "data" / "fear_greed.json",
            userdir / "data" / "custom" / "fear_greed.csv",
            userdir / "data" / "custom" / "fear_greed.json",
        ]

    def _load_fg_series(self, pair: str) -> pd.Series:
        """
        다양한 포맷(csv/json/jsonl)을 수용해서 FG 시계열 반환(UTC, float)
        파일 없거나 파싱 실패 → 상수 50 폴백
        """
        for p in self._candidate_fg_paths(pair):
            if not p.exists():
                continue
            try:
                if p.suffix.lower() == ".csv":
                    df = pd.read_csv(p)
                else:
                    # json or jsonl
                    txt = p.read_text(encoding="utf-8").strip()
                    try:
                        data = json.loads(txt)  # list or dict
                        if isinstance(data, dict):
                            data = data.get("data", [])
                    except Exception:
                        # jsonl
                        data = [json.loads(line) for line in txt.splitlines() if line.strip()]
                    df = pd.DataFrame(data)
                # 컬럼 정규화: timestamp(UTC sec) or date(ISO), value
                if "timestamp" in df.columns:
                    t = pd.to_datetime(df["timestamp"], unit="s", utc=True, errors="coerce")
                elif "date" in df.columns:
                    t = pd.to_datetime(df["date"], utc=True, errors="coerce")
                else:
                    continue
                s = pd.Series(df["value"].astype(float).values, index=t, name="fg").sort_index()
                s = s.dropna().ffill()
                if len(s):
                    return s
            except Exception:
                continue

        # 폴백(상수 50, 더미 인덱스)
        idx = pd.date_range("2000-01-01", periods=1, tz="UTC")
        return pd.Series([50.0], index=idx, name="fg")

    # ---------------- 지표 ----------------
    def populate_indicators(self, dataframe: pd.DataFrame, metadata: Dict[str, Any]) -> pd.DataFrame:
        df = dataframe.copy()
        # UTC 통일(백테 DF가 naive여도 utc=True로 tz-aware 변환)
        df["date"] = pd.to_datetime(df["date"], utc=True, errors="coerce")

        p = int(self.buy_dc_period.value)

        # Donchian 상단/하단 (상단은 직전값으로 shift(1) → 룩어헤드 제거)
        df["dc_high"] = df["high"].rolling(p, min_periods=p).max().shift(1)
        df["dc_low"] = df["low"].rolling(p, min_periods=p).min()

        # 거래량 배수 필터
        vol_ma = df["volume"].rolling(p, min_periods=p).mean()
        df["vol_ok"] = df["volume"] > (vol_ma * float(self.buy_vol_mult.value))

        # Fear & Greed 병합 (옵션 데이터) - backward asof + tolerance
        try:
            s = self._load_fg_series(metadata.get("pair", "BTC/USDT"))
            fgdf = s.rename("fg").to_frame().reset_index().rename(columns={"index": "date"})
            df = pd.merge_asof(
                df.sort_values("date"),
                fgdf.sort_values("date"),
                on="date",
                direction="backward",
                tolerance=pd.Timedelta("30D"),
            )
            df["fg"] = df["fg"].fillna(50.0).astype(float)
        except Exception:
            df["fg"] = 50.0

        return df

    # ---------------- 매수 ----------------
    def populate_buy_trend(self, dataframe: pd.DataFrame, metadata: Dict[str, Any]) -> pd.DataFrame:
        df = dataframe.copy()

        cond_dc = (df["close"] > df["dc_high"])   # 직전 Donchian 상단 돌파
        cond_vol = df["vol_ok"]                   # 거래량 배수 충족

        use_fg = int(self.use_fg.value) == 1
        th = int(self.buy_fg_threshold.value)
        cond_fg = (df["fg"] >= th) if use_fg else True

        df.loc[:, "buy"] = 0
        df.loc[cond_dc & cond_vol & cond_fg, "buy"] = 1
        return df

    # ---------------- 매도 ----------------
    def populate_sell_trend(self, dataframe: pd.DataFrame, metadata: Dict[str, Any]) -> pd.DataFrame:
        df = dataframe.copy()
        # 단순: Donchian 하단 이탈 시 청산
        cond_exit = (df["close"] < df["dc_low"])
        df.loc[:, "sell"] = 0
        df.loc[cond_exit, "sell"] = 1
        return df
