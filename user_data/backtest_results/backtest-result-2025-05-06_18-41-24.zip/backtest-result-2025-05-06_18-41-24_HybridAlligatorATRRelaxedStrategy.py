# 파일명: hybrid_alligator_atr_relaxed.py
from freqtrade.strategy import IStrategy
from freqtrade.strategy.parameters import RealParameter, IntParameter
import talib.abstract as ta
import pandas as pd
from pandas import DataFrame


class HybridAlligatorATRRelaxedStrategy(IStrategy):
    """
    5m Alligator+ATR+Volume/Volatility+HighBreakout + ADX/DI 필터
    + 30m Alligator 다중 타임프레임 필터 (Relaxed)
    Hyperopt 대상: buy 파라미터 + stoploss_param
    """

    timeframe = '5m'
    startup_candle_count = 50

    # ROI, 고정 stoploss
    minimal_roi = {"0": 0.02, "10": 0.01, "30": 0}
    stoploss = -0.05

    # 하이퍼옵트용 stoploss 파라미터
    stoploss_param = RealParameter(-0.10, -0.01, default=-0.05,
                                   space='sell', optimize=True, load=True)

    trailing_stop = True
    trailing_stop_positive = 0.03
    trailing_stop_positive_offset = 0.05

    process_only_new_candles = True
    use_custom_stoploss = True
    can_long = True
    can_short = False

    # Hyperopt 대상 파라미터 (buy)
    atr_period      = IntParameter(8, 21,  default=14, space='buy', optimize=True, load=True)
    vol_multiplier  = RealParameter(1.0, 3.0, default=1.2,  space='buy', optimize=True, load=True)
    volat_threshold = RealParameter(0.003,0.02, default=0.005,space='buy', optimize=True, load=True)
    high_lookback   = IntParameter(1, 7,   default=3,   space='buy', optimize=True, load=True)

    # 하이퍼옵트 결과값 (기본값)
    buy_params = {
        "atr_period":     18,
        "high_lookback":   7,
        "vol_multiplier":  1.68035,
        "volat_threshold": 0.00928,
    }
    sell_params = {
        "stoploss_param": -0.04678,
    }

    def custom_stoploss(self, pair, trade, current_time, current_rate, current_profit, **kwargs) -> float:
        return float(self.stoploss_param.value)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 5m Alligator
        hl2 = (dataframe['high'] + dataframe['low']) / 2
        dataframe['jaw'] = pd.Series(
            ta.EMA(hl2, timeperiod=13),
            index=dataframe.index
        ).shift(8)
        dataframe['teeth'] = pd.Series(
            ta.EMA(hl2, timeperiod=8),
            index=dataframe.index
        ).shift(5)
        dataframe['lips'] = pd.Series(
            ta.EMA(hl2, timeperiod=5),
            index=dataframe.index
        ).shift(3)

        # ADX / DI
        dataframe['adx']     = ta.ADX(dataframe, timeperiod=14)
        dataframe['plusdi']  = ta.PLUS_DI(dataframe, timeperiod=14)
        dataframe['minusdi'] = ta.MINUS_DI(dataframe, timeperiod=14)

        # ATR & Volume MA
        dataframe['atr']    = ta.ATR(dataframe, timeperiod=int(self.atr_period.value))
        dataframe['vol_ma'] = dataframe['volume'].rolling(10).mean()

        # 30m Alligator (multi-TF)
        big_df = self.dp.get_pair_dataframe(metadata['pair'], timeframe='30m')
        hl2b = (big_df['high'] + big_df['low']) / 2
        jaw_b = pd.Series(ta.EMA(hl2b, timeperiod=13), index=big_df.index).shift(8)
        teeth_b = pd.Series(ta.EMA(hl2b, timeperiod=8), index=big_df.index).shift(5)
        lips_b = pd.Series(ta.EMA(hl2b, timeperiod=5), index=big_df.index).shift(3)

        # 마지막 캔들 기준 상승/하락 bool
        is_up = (lips_b.iloc[-1] > teeth_b.iloc[-1] > jaw_b.iloc[-1])
        is_down = (lips_b.iloc[-1] < teeth_b.iloc[-1] < jaw_b.iloc[-1])
        dataframe['big_uptrend'] = is_up
        dataframe['big_downtrend'] = is_down

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        if dataframe.empty:
            return dataframe

        # 기본 브레이크아웃
        breakout      = dataframe['close'] > (dataframe['close'].shift(1) + dataframe['atr'])
        volume_ok     = dataframe['volume'] > dataframe['vol_ma'] * self.vol_multiplier.value
        volatility_ok = dataframe['atr'] > (dataframe['close'] * self.volat_threshold.value)
        recent_high   = dataframe['high'].rolling(int(self.high_lookback.value)).max().shift(1)
        high_breakout = dataframe['close'] > recent_high

        # ADX/DI filter
        di_ok    = dataframe['plusdi'] > dataframe['minusdi']
        trend_ok = (dataframe['adx'] > 25) & di_ok

        # multi-TF 반드시 상승일 때만
        mtf_ok = dataframe['big_uptrend'] & trend_ok

        entry = breakout & volume_ok & volatility_ok & high_breakout & mtf_ok
        dataframe.loc[entry, 'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[dataframe['lips'] < dataframe['teeth'], 'exit_long'] = 1
        return dataframe
