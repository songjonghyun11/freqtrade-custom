# 파일명: hybrid_alligator_atr_relaxed.py
from freqtrade.strategy import IStrategy
from freqtrade.strategy.parameters import RealParameter, IntParameter
import talib.abstract as ta
import pandas as pd
from pandas import DataFrame

class HybridAlligatorATRRelaxedStrategy(IStrategy):
    timeframe = '5m'
    startup_candle_count = 50

    minimal_roi = {"0": 0.02, "10": 0.01, "30": 0}
    stoploss = -0.05
    stoploss_param = RealParameter(-0.10, -0.01, default=-0.05,
                                   space='sell', optimize=True, load=True)

    trailing_stop = True
    trailing_stop_positive = 0.03
    trailing_stop_positive_offset = 0.05

    process_only_new_candles = True
    use_custom_stoploss = True
    can_long = True
    can_short = False

    atr_period      = IntParameter(8, 21,  default=14, space='buy', optimize=True, load=True)
    vol_multiplier  = RealParameter(1.0, 3.0, default=1.2,  space='buy', optimize=True, load=True)
    volat_threshold = RealParameter(0.003,0.02, default=0.005,space='buy', optimize=True, load=True)
    high_lookback   = IntParameter(1, 7,   default=3,   space='buy', optimize=True, load=True)

    buy_params = {
        "atr_period":     14,
        "high_lookback":   3,
        "vol_multiplier":  1.2,
        "volat_threshold": 0.005,
    }
    sell_params = {
        "stoploss_param": -0.05,
    }

    def custom_stoploss(self, pair, trade, current_time, current_rate, current_profit, **kwargs) -> float:
        return float(self.stoploss_param.value)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        hl2 = (dataframe['high'] + dataframe['low']) / 2
        dataframe['jaw']   = pd.Series(ta.EMA(hl2, timeperiod=13), index=dataframe.index).shift(8)
        dataframe['teeth'] = pd.Series(ta.EMA(hl2, timeperiod=8),  index=dataframe.index).shift(5)
        dataframe['lips']  = pd.Series(ta.EMA(hl2, timeperiod=5),  index=dataframe.index).shift(3)

        dataframe['adx']     = ta.ADX(dataframe, timeperiod=14)
        dataframe['plusdi']  = ta.PLUS_DI(dataframe, timeperiod=14)
        dataframe['minusdi'] = ta.MINUS_DI(dataframe, timeperiod=14)

        dataframe['atr']    = ta.ATR(dataframe, timeperiod=int(self.atr_period.value))
        dataframe['vol_ma'] = dataframe['volume'].rolling(10).mean()
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        if dataframe.empty:
            return dataframe

        # ATR 브레이크아웃
        breakout = dataframe['close'] > (dataframe['close'].shift(1) + dataframe['atr'])

        # Volume 필터
        volume_ok = dataframe['volume'] > dataframe['vol_ma'] * self.vol_multiplier.value

        # Volatility 필터
        volatility_ok = dataframe['atr'] > (dataframe['close'] * self.volat_threshold.value)

        # → High-breakout 필터를 잠시 제거합니다.
        # recent_high = dataframe['high'].rolling(int(self.high_lookback.value)).max().shift(1)
        # high_breakout = dataframe['close'] > recent_high

        entry_signal = breakout & volume_ok & volatility_ok
        dataframe.loc[entry_signal, 'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[dataframe['lips'] < dataframe['teeth'], 'exit_long'] = 1
        return dataframe
