from freqtrade.strategy.interface import IStrategy
from pandas import DataFrame
import pandas as pd
from pathlib import Path
import sys

# === collectors 경로 추가 ===
BASE_DIR = Path(__file__).resolve().parents[1]              # /freqtrade/user_data
COLLECTORS_DIR = BASE_DIR / "collectors"
if str(COLLECTORS_DIR) not in sys.path:
    sys.path.insert(0, str(COLLECTORS_DIR))

from fear_greed import FearGreedCollector
try:
    from freqtrade.strategy import IntParameter
    HAVE_HYPER = True
except Exception:
    HAVE_HYPER = False


class TestDonchianFearGreedStrategy(IStrategy):
    timeframe = "5m"
    can_short = False

    # ✅ Donchian(20) 계산 워밍업 보장
    startup_candle_count = 20

    # ✅ 현실적인 ROI 테이블(시간 경과에 따라 요구수익 하향)
    # 키는 "분" 단위 경과시간. 예: 0분 이후 3%, 240분 이후 2%, 720분 이후 1%
    minimal_roi = {
        "0": 0.03,
        "240": 0.02,
        "720": 0.01
    }

    # Config에서 stoploss를 오버라이드할 수 있음(로그에 표시됨)
    stoploss = -0.23

    if HAVE_HYPER:
        buy_fg_threshold = IntParameter(30, 80, default=55, space='buy')
    else:
        buy_fg_threshold = None

    plot_config = {
        "main_plot": {"donchian_high": {"color": "orange"}},
        "subplots": {"FG": {"fg_value": {"color": "green"}}},
    }

    debug = True

    @staticmethod
    def _pair_folder(pair: str) -> str:
        return pair.replace("/", "_")  # BTC/USDT -> BTC_USDT

    def _load_fg_series(self, pair_folder: str) -> pd.Series:
        fg = FearGreedCollector(mode="backtest", data_dir=str(COLLECTORS_DIR / "data"))
        data = fg._load_jsonl(pair_folder, "fear_greed")  # {ts:int -> {...}}
        if not data:
            return pd.Series(dtype=float)
        ts = sorted(data.keys())
        vals = [float(data[t]["value"]) for t in ts]
        s = pd.Series(vals, index=pd.to_datetime(ts, unit="s", utc=True), name="fg_value")
        return s.sort_index()

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Donchian high(20)
        dataframe["donchian_high"] = dataframe["high"].rolling(20).max()

        # FearGreed 병합 (UTC tz-aware ↔ tz-aware)
        pair_folder = self._pair_folder(metadata["pair"])
        fg_series = self._load_fg_series(pair_folder)

        if not fg_series.empty:
            df = dataframe.copy()
            df["_dt"] = pd.to_datetime(df["date"], utc=True)
            merged = pd.merge_asof(
                df.sort_values("_dt"),
                fg_series.to_frame().sort_index(),
                left_on="_dt",
                right_index=True,
                direction="backward",
            )
            dataframe["fg_value"] = merged["fg_value"].ffill().fillna(50.0)
        else:
            dataframe["fg_value"] = 50.0

        if self.debug:
            tail = dataframe[["date", "close", "donchian_high", "fg_value"]].tail(3)
            print("[DEBUG][FG merge tail]\n", tail.to_string(index=False))

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe["enter_long"] = 0

        # Donchian 돌파(직전봉 기준)
        cond_break = dataframe["close"] > dataframe["donchian_high"].shift(1)

        # FG 임계치
        thr = 55
        if self.buy_fg_threshold is not None:
            try:
                thr = int(getattr(self, "buy_fg_threshold").value)
            except Exception:
                thr = 55

        cond_fg = dataframe["fg_value"] >= thr
        cond = cond_break & cond_fg

        dataframe.loc[cond, "enter_long"] = 1

        if self.debug:
            print(f"[DEBUG] FG threshold={thr}, entries={int(cond.sum())}")

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe["exit_long"] = 0

        # ✅ 간단한 Exit: 고가 채널 재이탈 시 청산(보수적)
        # 더 공세적으로는 'close < donchian_high.shift(2)' 등으로 완화 가능
        exit_cond = dataframe["close"] < dataframe["donchian_high"].shift(1)
        dataframe.loc[exit_cond, "exit_long"] = 1

        return dataframe
