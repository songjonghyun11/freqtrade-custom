from freqtrade.strategy.interface import IStrategy
from freqtrade.strategy.parameters import IntParameter
from pandas import DataFrame

from entry_signals.donchian import DonchianBreakoutSignal
from mysignal import Signal


class TestDonchianSignalStrategy(IStrategy):
    minimal_roi = {"0": 0.1}
    stoploss = -0.3
    timeframe = '5m'
    startup_candle_count = 30  # ✅ Donchian에 필요한 최소값 설정!

    some_param = IntParameter(10, 30, default=20, space="buy", optimize=True, load=True)

    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self.signal = DonchianBreakoutSignal()

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        signal: Signal = self.signal.generate(
            dataframe, 
            metadata["pair"], 
            {"some_param": self.some_param.value}
        )
        return signal.merge(dataframe)  # ✅ 핵심: Signal → DataFrame 병합

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe["exit_long"] = 0
        return dataframe

