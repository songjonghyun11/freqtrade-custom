from freqtrade.strategy.interface import IStrategy
from pandas import DataFrame
import pandas as pd
from pathlib import Path
import sys

# === collectors 경로 추가 ===
BASE_DIR = Path(__file__).resolve().parents[1]              # /freqtrade/user_data
COLLECTORS_DIR = BASE_DIR / "collectors"
if str(COLLECTORS_DIR) not in sys.path:
    sys.path.insert(0, str(COLLECTORS_DIR))

from fear_greed import FearGreedCollector

# 하이퍼옵트 파라미터(있으면 사용)
try:
    from freqtrade.strategy import IntParameter, DecimalParameter
    HAVE_HYPER = True
except Exception:
    HAVE_HYPER = False


class TestDonchianFearGreedStrategy(IStrategy):
    timeframe = "5m"
    can_short = False
    startup_candle_count = 20

    # 현실적 ROI
    minimal_roi = {
        "0": 0.03,
        "240": 0.02,
        "720": 0.01
    }

    stoploss = -0.23

    # === 토글/기본값 ===
    use_fg_filter = True      # FG 필터 켜기/끄기
    _fg_cache = None          # 글로벌 FG 시리즈 캐시

    # === 하이퍼옵트 파라미터(옵션) ===
    if HAVE_HYPER:
        buy_fg_threshold = IntParameter(40, 80, default=52, space='buy')     # 60 -> 52
        buy_atr_mult     = DecimalParameter(0.10, 1.50, default=0.50, decimals=2, space='buy')
        buy_vol_mult     = DecimalParameter(1.00, 2.50, default=1.20, decimals=2, space='buy')
        sell_lookback    = IntParameter(2, 6, default=4, space='sell')
        sell_ema_period  = IntParameter(12, 36, default=20, space='sell')
    else:
        buy_fg_threshold = None
        buy_atr_mult = None
        buy_vol_mult = None
        sell_lookback = None
        sell_ema_period = None

    plot_config = {
        "main_plot": {
            "donchian_high": {"color": "orange"},
            "ema_exit": {"color": "blue"},
        },
        "subplots": {
            "FG": {"fg_value": {"color": "green"}},
            "ATR": {"atr": {"color": "purple"}},
            "VOL": {"vol_sma": {"color": "gray"}},
        },
    }

    debug = True

    @staticmethod
    def _pair_folder(pair: str) -> str:
        return pair.replace("/", "_")  # BTC/USDT -> BTC_USDT

    def _load_fg_series_global_first(self) -> pd.Series:
        """
        1) collectors/data/fear_greed.jsonl  (글로벌 지수)
        2) collectors/data/<PAIR>/fear_greed.jsonl (페어별, 있으면)
        3) 없으면 빈 Series -> 나중에 50으로 채움
        결과는 self._fg_cache에 1회 캐싱.
        """
        if self._fg_cache is not None:
            return self._fg_cache

        fg_coll = FearGreedCollector(mode="backtest", data_dir=str(COLLECTORS_DIR / "data"))

        # 1) 글로벌 우선
        global_map = fg_coll._load_jsonl("", "fear_greed")  # 내부에서 폴더 합쳐 처리
        series = None
        if global_map:
            ts = sorted(global_map.keys())
            vals = [float(global_map[t]["value"]) for t in ts]
            series = pd.Series(vals, index=pd.to_datetime(ts, unit="s", utc=True), name="fg_value").sort_index()

        # 캐시 저장
        self._fg_cache = series if series is not None else pd.Series(dtype=float)
        return self._fg_cache

    def _load_fg_series_pair_fallback(self, pair_folder: str) -> pd.Series:
        """
        글로벌이 비었으면 페어별로 시도. 최종 실패 시 빈 Series.
        """
        fg = FearGreedCollector(mode="backtest", data_dir=str(COLLECTORS_DIR / "data"))
        data = fg._load_jsonl(pair_folder, "fear_greed")  # {ts:int -> {...}}
        if not data:
            return pd.Series(dtype=float)
        ts = sorted(data.keys())
        vals = [float(data[t]["value"]) for t in ts]
        s = pd.Series(vals, index=pd.to_datetime(ts, unit="s", utc=True), name="fg_value")
        return s.sort_index()

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Donchian(20)
        dataframe["donchian_high"] = dataframe["high"].rolling(20).max()

        # ATR(14) / EMA / 볼륨SMA(20)
        tr1 = (dataframe["high"] - dataframe["low"]).abs()
        tr2 = (dataframe["high"] - dataframe["close"].shift()).abs()
        tr3 = (dataframe["low"]  - dataframe["close"].shift()).abs()
        dataframe["tr"]  = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        dataframe["atr"] = dataframe["tr"].rolling(14).mean()
        ema_period = 20 if self.sell_ema_period is None else int(getattr(self, "sell_ema_period", 20).value if HAVE_HYPER else 20)
        dataframe["ema_exit"] = dataframe["close"].ewm(span=ema_period, adjust=False).mean()
        dataframe["vol_sma"]  = dataframe["volume"].rolling(20).mean()

        # FearGreed 병합 (global -> pair fallback -> 50.0)
        pair_folder = self._pair_folder(metadata["pair"])
        fg_series = self._load_fg_series_global_first()
        if fg_series is None or fg_series.empty:
            fg_series = self._load_fg_series_pair_fallback(pair_folder)

        if fg_series is not None and not fg_series.empty:
            df = dataframe.copy()
            df["_dt"] = pd.to_datetime(df["date"], utc=True)
            merged = pd.merge_asof(
                df.sort_values("_dt"),
                fg_series.to_frame().sort_index(),
                left_on="_dt",
                right_index=True,
                direction="backward",
            )
            dataframe["fg_value"] = merged["fg_value"].ffill().fillna(50.0)
        else:
            dataframe["fg_value"] = 50.0

        if self.debug:
            tail = dataframe[["date","close","donchian_high","atr","vol_sma","fg_value"]].tail(3)
            print("[DEBUG][IND tail]\n", tail.to_string(index=False))

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe["enter_long"] = 0

        # === 돌파 강도: close가 직전채널 + ATR버퍼 초과 ===
        atr_k = 0.50 if self.buy_atr_mult is None else float(getattr(self, "buy_atr_mult", 0.50).value if HAVE_HYPER else 0.50)
        breakout = (dataframe["close"] - dataframe["donchian_high"].shift(1)) > (atr_k * dataframe["atr"])

        # === 볼륨 필터 ===
        vol_k = 1.20 if self.buy_vol_mult is None else float(getattr(self, "buy_vol_mult", 1.20).value if HAVE_HYPER else 1.20)
        vol_ok = dataframe["volume"] > (vol_k * dataframe["vol_sma"])

        # === FG 필터 === (토글 가능)
        fg_thr = 52 if self.buy_fg_threshold is None else int(getattr(self, "buy_fg_threshold", 52).value if HAVE_HYPER else 52)
        if self.use_fg_filter:
            fg_ok = dataframe["fg_value"] >= fg_thr
        else:
            fg_ok = pd.Series(True, index=dataframe.index)

        cond = breakout & vol_ok & fg_ok
        dataframe.loc[cond, "enter_long"] = 1

        if self.debug:
            print(
                f"[DEBUG][ENTRY] pair={metadata['pair']} "
                f"breakout={int(breakout.sum())}  vol_ok={int(vol_ok.sum())}  fg_ok={int(fg_ok.sum())}  "
                f"entries={int(cond.sum())} | atr_k={atr_k} vol_k={vol_k} fg_thr={fg_thr} use_fg={self.use_fg_filter}"
            )

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe["exit_long"] = 0

        # === 완화형 출구: 채널 재이탈 + EMA 동행 + 과거 N봉 내 채널 하향 지속 ===
        lb = 4 if self.sell_lookback is None else int(getattr(self, "sell_lookback", 4).value if HAVE_HYPER else 4)

        re_enter_zone = dataframe["close"] < dataframe["donchian_high"].shift(lb)
        ema_filter    = dataframe["close"] < dataframe["ema_exit"]

        exit_cond = re_enter_zone & ema_filter
        dataframe.loc[exit_cond, "exit_long"] = 1

        return dataframe
