# -*- coding: utf-8 -*-
from typing import Dict, Any
import os
import json
import pandas as pd
import numpy as np

from freqtrade.strategy.interface import IStrategy

# 하이퍼옵트 파라미터 (있으면 사용, 없으면 FALLBACK)
try:
    from freqtrade.strategy.parameter import IntParameter, DecimalParameter
    HAVE_HYPER = True
except Exception:
    IntParameter = DecimalParameter = None
    HAVE_HYPER = False


class TestDonchianFearGreedStrategy(IStrategy):
    """
    Donchian 돌파 + 거래량 + 공포/탐욕(Fear&Greed) 필터 결합 테스트 전략
    - Donchian upper(20) 위로 ATR*k 만큼 돌파
    - 거래량 > SMA(volume, 20) * k
    - (옵션) fear&greed >= threshold
    - 첫 봉만 진입(디바운스)
    - 단순 EMA 기반 청산 + ROI 테이블
    """

    # === 기본 설정 ===
    timeframe: str = "5m"
    process_only_new_candles: bool = True
    startup_candle_count: int = 20

    minimal_roi = {
        "0": 0.03,
        "240": 0.02,
        "720": 0.01,
    }
    stoploss: float = -0.23
    use_exit_signal: bool = True
    exit_profit_only: bool = False
    ignore_roi_if_entry_signal: bool = False

    # FG 필터 기본 토글(하이퍼옵트가 없을 때 사용)
    use_fg_filter: bool = True

    # === 하이퍼옵트 파라미터(옵션) ===
    if HAVE_HYPER:
        buy_fg_threshold = IntParameter(40, 80, default=52, space="buy")
        buy_atr_mult     = DecimalParameter(0.10, 1.50, default=0.50, decimals=2, space="buy")
        buy_vol_mult     = DecimalParameter(1.00, 2.50, default=1.20, decimals=2, space="buy")

        sell_lookback   = IntParameter(2, 6, default=4, space="sell")
        sell_ema_period = IntParameter(12, 36, default=20, space="sell")

        # 👇 추가된 부분: FG 사용 여부도 하이퍼옵트 대상
        use_fg          = IntParameter(0, 1, default=1, space="buy")
    else:
        buy_fg_threshold = None
        buy_atr_mult = None
        buy_vol_mult = None
        sell_lookback = None
        sell_ema_period = None
        use_fg = None

    # ========== 유틸 ==========

    @staticmethod
    def _pair_to_symbol_dir(pair: str) -> str:
        """
        'BTC/USDT' -> 'BTC_USDT'
        """
        return pair.replace("/", "_")

    @staticmethod
    def _ensure_utc_index(df: pd.DataFrame) -> pd.DatetimeIndex:
        idx = pd.DatetimeIndex(df.index)
        if idx.tz is None:
            idx = idx.tz_localize("UTC")
        else:
            idx = idx.tz_convert("UTC")
        return idx

    def _fg_path(self, pair: str) -> str:
        """
        collectors/data/<SYMBOL>/fear_greed.json 의 절대경로 생성
        (__file__ 기준 상대경로를 사용하여 컨테이너 내에서도 안전)
        """
        base = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "collectors", "data"))
        sym = self._pair_to_symbol_dir(pair)
        return os.path.join(base, sym, "fear_greed.json")

    def _load_fear_greed_df(self, pair: str) -> pd.DataFrame:
        """
        fear_greed.json(JSON Lines) -> DataFrame(['date','fg_value'])
        없으면 기본값(50.0)을 하나만 가진 DF 리턴
        """
        path = self._fg_path(pair)
        if not os.path.exists(path):
            # 기본값 하나
            return pd.DataFrame(
                {"date": [pd.Timestamp("1970-01-01", tz="UTC")], "fg_value": [50.0]}
            )

        rows = []
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                    ts = int(obj.get("timestamp", 0))
                    val = float(obj.get("value", 50.0))
                    rows.append(
                        {
                            "date": pd.to_datetime(ts, unit="s", utc=True),
                            "fg_value": val,
                        }
                    )
                except Exception:
                    # 깨진 라인은 무시
                    continue

        if not rows:
            return pd.DataFrame(
                {"date": [pd.Timestamp("1970-01-01", tz="UTC")], "fg_value": [50.0]}
            )

        df = pd.DataFrame(rows).sort_values("date")
        return df

    @staticmethod
    def _atr(high: pd.Series, low: pd.Series, close: pd.Series, period: int = 14) -> pd.Series:
        """
        단순 ATR(rolling mean of TrueRange)
        """
        tr1 = (high - low).abs()
        tr2 = (high - close.shift(1)).abs()
        tr3 = (low - close.shift(1)).abs()
        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        return tr.rolling(period).mean()

    # ========== 보조지표 구성 ==========

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: Dict[str, Any]) -> pd.DataFrame:
        df = dataframe.copy()

        # 인덱스 UTC 정규화 + date 컬럼 생성
        idx_utc = self._ensure_utc_index(df)
        df.index = idx_utc
        df["date"] = idx_utc

        # Donchian 상단, ATR, 거래량 SMA
        donch_n = 20
        df["donchian_high"] = df["high"].rolling(donch_n).max()

        df["atr"] = self._atr(df["high"], df["low"], df["close"], period=14)

        vol_n = 20
        df["vol_sma"] = df["volume"].rolling(vol_n).mean()

        # Fear&Greed merge_asof (UTC, 뒤로 당겨 매칭)
        fg_df = self._load_fear_greed_df(metadata["pair"])
        fg_df = fg_df.sort_values("date")
        df = pd.merge_asof(
            df.sort_values("date"),
            fg_df[["date", "fg_value"]],
            on="date",
            direction="backward",
            tolerance=pd.Timedelta("30D"),
        )
        df["fg_value"] = df["fg_value"].fillna(50.0)

        # 청산용 EMA
        sell_ema_period = int(self.sell_ema_period.value) if (HAVE_HYPER and self.sell_ema_period is not None) else 20
        df["ema_sell"] = df["close"].ewm(span=sell_ema_period, adjust=False).mean()

        # 디버그: 페어별 꼬리 3줄
        tail = df[["date", "close", "donchian_high", "atr", "vol_sma", "fg_value"]].tail(3)
        print("[DEBUG][IND tail]\n", tail)

        return df

    # ========== 엔트리/엑싯 시그널 ==========

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: Dict[str, Any]) -> pd.DataFrame:
        df = dataframe.copy()

        # ---- 하이퍼옵트/파라미터 로드 ----
        atr_k  = float(self.buy_atr_mult.value) if (HAVE_HYPER and self.buy_atr_mult is not None) else 0.50
        vol_k  = float(self.buy_vol_mult.value) if (HAVE_HYPER and self.buy_vol_mult is not None) else 1.20
        fg_thr = int(self.buy_fg_threshold.value) if (HAVE_HYPER and self.buy_fg_threshold is not None) else 55

        # 👇 핵심 수정: 하이퍼옵트(use_fg)가 있으면 그것을, 아니면 기본 토글(use_fg_filter)을 사용
        use_fg = bool(self.use_fg.value) if (HAVE_HYPER and hasattr(self, "use_fg") and self.use_fg is not None) \
                 else bool(self.use_fg_filter)

        # ---- 조건식 ----
        # Donchian 상단 + ATR*k 만큼의 여유로 진입(약한 미세돌파 억제)
        breakout = df["close"] > (df["donchian_high"] + atr_k * df["atr"])

        # 거래량 필터
        vol_ok = df["volume"] > (df["vol_sma"] * vol_k)

        # FG 필터(옵션)
        if use_fg:
            fg_ok = df["fg_value"] >= fg_thr
        else:
            fg_ok = pd.Series(True, index=df.index)

        base = breakout & vol_ok & fg_ok

        # 디바운스(한 구간에서 첫 봉만 진입)
        first = base & (~base.shift(1).fillna(False))
        df["enter_long"] = first.astype(int)

        # 통계 로그
        print(
            f"[DEBUG][ENTRY] pair={metadata['pair']} "
            f"breakout={int(breakout.sum())}  vol_ok={int(vol_ok.sum())}  fg_ok={int(fg_ok.sum())}  "
            f"entries={int(df['enter_long'].sum())} | atr_k={atr_k} vol_k={vol_k} fg_thr={fg_thr} use_fg={use_fg}"
        )

        return df

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: Dict[str, Any]) -> pd.DataFrame:
        df = dataframe.copy()

        lookback = int(self.sell_lookback.value) if (HAVE_HYPER and self.sell_lookback is not None) else 4

        # 단순: EMA 아래로 꺾이면 청산 시그널(약간의 지연 완화 위해 lookback 활용)
        # 최근 lookback 봉 중 한 번이라도 close>EMA 였다가 현재 close<EMA 로 전환된 첫 봉
        above = df["close"] > df["ema_sell"]
        turned_down = (~above) & (above.shift(lookback, fill_value=False))
        df["exit_long"] = turned_down.astype(int)

        return df
