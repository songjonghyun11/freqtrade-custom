import numpy as np
import pandas as pd
from pandas import DataFrame

import talib.abstract as ta
from freqtrade.strategy import IStrategy
from freqtrade.strategy.parameters import RealParameter, IntParameter, DecimalParameter
from freqtrade.strategy import IntParameter

from freqtrade.persistence import Trade
from entry_signals.rsi_momentum import RSIMomentumSignal
from entry_signals.supertrend import SupertrendSignal
from entry_signals.ema_crossover import EMACrossoverSignal
from entry_signals.alligator_atr import AlligatorATRSignal
from entry_signals.donchian import DonchianBreakoutSignal
from exit_signals.ema_cross_exit import EMACrossExit
from risk.dynamic_stoploss import DynamicStoploss

from datetime import datetime   
from typing import Optional    

class HybridAlligatorATRRelaxedStrategy(IStrategy):
    INTERFACE_VERSION = 3

    timeframe = '5m'
    can_short = False
    process_only_new_candles = True
    startup_candle_count = 50

    use_custom_stoploss = True
    use_exit_signal = True
    ignore_roi_if_entry_signal = False
    
    minimal_roi = {
        "0": 0.086,
        "31": 0.052,
        "83": 0.022,
        "178": 0
    }
    stoploss = -0.341

    # 청산 신호용 하이퍼옵트 파라미터 선언
    exit_fast_ema = IntParameter(5, 20, default=10, space="sell")                  # 10
    exit_slow_ema = IntParameter(10, 50, default=22, space="sell")                 # 22
    sl_atr_multiplier = RealParameter(1.0, 3.5, default=2.55048, space="sell")     # 2.55048


    # 진입 신호용 파라미터
    supertrend_atr_period = IntParameter(7, 20, default=10, space="buy")           # 10
    supertrend_atr_multiplier = RealParameter(1.0, 6.0, default=4.70434, space="buy") # 4.70434
    atr_period = IntParameter(7, 21, default=18, space="buy")                      # 18
    donchian_period = IntParameter(10, 40, default=32, space="buy")                # 32
    ema_fast_period = IntParameter(7, 30, default=24, space="buy")                 # 24
    ema_slow_period = IntParameter(20, 120, default=98, space="buy")               # 98
    high_lookback = IntParameter(2, 6, default=5, space="buy")                     # 5
    vol_multiplier = RealParameter(0.5, 3.5, default=2.53472, space="buy")         # 2.53472
    volat_threshold = RealParameter(0.001, 0.05, default=0.04403, space="buy")     # 0.04403
    rsi_period = IntParameter(8, 20, default=12, space="buy")                      # 12
    rsi_threshold = IntParameter(40, 70, default=56, space="buy")                  # 56
    trend_ema_fast_period = IntParameter(7, 30, default=19, space="buy")           # 19
    trend_ema_slow_period = IntParameter(20, 100, default=25, space="buy")         # 25
    trend_vol_ma_period = IntParameter(10, 60, default=27, space="buy")            # 27




    stoploss_param = DecimalParameter(-0.04, -0.01, default=-0.334, space="stoploss")

    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self.entry_signals = [
        AlligatorATRSignal(),
        DonchianBreakoutSignal(),
        EMACrossoverSignal(),
        SupertrendSignal(),
        RSIMomentumSignal()
        ]
        self.exit_signals = [EMACrossExit()]
        self.risk_module = DynamicStoploss()

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        hl2 = (dataframe["high"] + dataframe["low"]) / 2
        dataframe['jaw'] = pd.Series(ta.EMA(hl2, timeperiod=13), index=dataframe.index).shift(8)
        dataframe['teeth'] = pd.Series(ta.EMA(hl2, timeperiod=8), index=dataframe.index).shift(5)
        dataframe['lips'] = pd.Series(ta.EMA(hl2, timeperiod=5), index=dataframe.index).shift(3)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        pair = metadata['pair']
        param_sets = [
        {   # AlligatorATRSignal
            'atr_period': self.atr_period.value,
            'high_lookback': self.high_lookback.value,
            'volat_threshold': self.volat_threshold.value,
            'vol_multiplier': self.vol_multiplier.value
        },
        {   # DonchianBreakoutSignal
            'donchian_period': self.donchian_period.value
        },
        {   # EMACrossoverSignal
            'ema_fast_period': self.ema_fast_period.value,
            'ema_slow_period': self.ema_slow_period.value
        },
        {   # SupertrendSignal (하이퍼옵스 연동)
            'atr_period': self.supertrend_atr_period.value,
            'atr_multiplier': self.supertrend_atr_multiplier.value
        },
        {   # SupertrendSignal (하이퍼옵스 연동)
            'rsi_period': self.rsi_period.value,
            'rsi_threshold': self.rsi_threshold.value
        },
        {   #trend_volumesignal
        'ema_fast_period': self.trend_ema_fast_period.value,
        'ema_slow_period': self.trend_ema_slow_period.value,
        'vol_ma_period': self.trend_vol_ma_period.value
        }
        # 필요 시 추가 신호/파라미터도 이 아래에 계속 확장
    ]
        for i, sig in enumerate(self.entry_signals):
            entry_cond = sig.generate(dataframe, pair, param_sets[i])
            dataframe.loc[entry_cond, 'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        param_sets = [{
            'exit_fast_ema': self.exit_fast_ema.value,
            'exit_slow_ema': self.exit_slow_ema.value
        }]
        for i, sig in enumerate(self.exit_signals):
            exit_cond = sig.generate(dataframe, metadata['pair'], param_sets[i])
            dataframe.loc[exit_cond, 'exit_long'] = 1
        return dataframe

    def custom_stoploss(self, pair: str, trade: Trade, current_time: datetime, current_rate: float,
                    current_profit: float, **kwargs) -> Optional[float]:
        return self.risk_module.adjust_stoploss(pair, trade, current_time, current_rate, current_profit, **kwargs)

    def _get_signal_param_sets(self, signals):
        if hasattr(self, 'ft_params') and isinstance(self.ft_params, dict):
            return [
                {k: v for k, v in self.ft_params.items()
                 if k.startswith(sig.__class__.__name__[:6].lower())}
                for sig in signals
            ]
        return [{} for _ in signals]
