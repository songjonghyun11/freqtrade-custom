import numpy as np
import pandas as pd
from pandas import DataFrame

import talib.abstract as ta
from freqtrade.strategy import IStrategy
from freqtrade.strategy.parameters import RealParameter, IntParameter, DecimalParameter
from freqtrade.strategy import IntParameter

from freqtrade.persistence import Trade
from entry_signals.rsi_momentum import RSIMomentumSignal
from entry_signals.supertrend import SupertrendSignal
from entry_signals.ema_crossover import EMACrossoverSignal
from entry_signals.alligator_atr import AlligatorATRSignal
from entry_signals.donchian import DonchianBreakoutSignal
from exit_signals.ema_cross_exit import EMACrossExit
from risk.dynamic_stoploss import DynamicStoploss

from datetime import datetime   
from typing import Optional    

class HybridAlligatorATRRelaxedStrategy(IStrategy):
    INTERFACE_VERSION = 3

    timeframe = '5m'
    can_short = False
    process_only_new_candles = True
    startup_candle_count = 50

    use_custom_stoploss = True
    use_exit_signal = True
    ignore_roi_if_entry_signal = False
    
    minimal_roi = {
        "0": 0.197,
        "30": 0.059,
        "75": 0.027,
        "160": 0
    }
    stoploss = -0.341

    # 청산 신호용 하이퍼옵트 파라미터 선언
    exit_fast_ema = IntParameter(5, 20, default=15, space="sell")
    exit_slow_ema = IntParameter(10, 40, default=29, space="sell")      # 29로 변경
    sl_atr_multiplier = RealParameter(1.0, 3.0, default=2.26545, space="sell") # 2.26545로 변경


    # 진입 신호용 파라미터
    supertrend_atr_period = IntParameter(7, 21, default=9, space="buy")     # 9로 변경
    supertrend_atr_multiplier = RealParameter(1.0, 5.0, default=2.31341, space="buy") # 2.31341로 변경
    atr_period = IntParameter(7, 21, default=7, space="buy")                # 7로 변경
    donchian_period = IntParameter(10, 40, default=31, space="buy")         # 31로 변경
    ema_fast_period = IntParameter(7, 30, default=21, space="buy")          # 21로 변경
    ema_slow_period = IntParameter(20, 100, default=21, space="buy")        # 21로 변경
    high_lookback = IntParameter(2, 6, default=6, space="buy")              # 6로 변경
    vol_multiplier = RealParameter(0.5, 3.0, default=1.90332, space="buy")  # 1.90332로 변경
    volat_threshold = RealParameter(0.001, 0.05, default=0.01336, space="buy") # 0.01336로 변경
    rsi_period = IntParameter(7, 21, default=8, space="buy")                # 8로 변경
    rsi_threshold = IntParameter(40, 60, default=52, space="buy")           # 52로 변경



    stoploss_param = DecimalParameter(-0.04, -0.01, default=-0.334, space="stoploss")

    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self.entry_signals = [
        AlligatorATRSignal(),
        DonchianBreakoutSignal(),
        EMACrossoverSignal(),
        SupertrendSignal(),
        RSIMomentumSignal()
        ]
        self.exit_signals = [EMACrossExit()]
        self.risk_module = DynamicStoploss()

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        hl2 = (dataframe["high"] + dataframe["low"]) / 2
        dataframe['jaw'] = pd.Series(ta.EMA(hl2, timeperiod=13), index=dataframe.index).shift(8)
        dataframe['teeth'] = pd.Series(ta.EMA(hl2, timeperiod=8), index=dataframe.index).shift(5)
        dataframe['lips'] = pd.Series(ta.EMA(hl2, timeperiod=5), index=dataframe.index).shift(3)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        pair = metadata['pair']
        param_sets = [
        {   # AlligatorATRSignal
            'atr_period': self.atr_period.value,
            'high_lookback': self.high_lookback.value,
            'volat_threshold': self.volat_threshold.value,
            'vol_multiplier': self.vol_multiplier.value
        },
        {   # DonchianBreakoutSignal
            'donchian_period': self.donchian_period.value
        },
        {   # EMACrossoverSignal
            'ema_fast_period': self.ema_fast_period.value,
            'ema_slow_period': self.ema_slow_period.value
        },
        {   # SupertrendSignal (하이퍼옵스 연동)
            'atr_period': self.supertrend_atr_period.value,
            'atr_multiplier': self.supertrend_atr_multiplier.value
        },
        {   # SupertrendSignal (하이퍼옵스 연동)
            'rsi_period': self.rsi_period.value,
            'rsi_threshold': self.rsi_threshold.value
        }
        # 필요 시 추가 신호/파라미터도 이 아래에 계속 확장
    ]
        for i, sig in enumerate(self.entry_signals):
            entry_cond = sig.generate(dataframe, pair, param_sets[i])
            dataframe.loc[entry_cond, 'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        param_sets = [{
            'exit_fast_ema': self.exit_fast_ema.value,
            'exit_slow_ema': self.exit_slow_ema.value
        }]
        for i, sig in enumerate(self.exit_signals):
            exit_cond = sig.generate(dataframe, metadata['pair'], param_sets[i])
            dataframe.loc[exit_cond, 'exit_long'] = 1
        return dataframe

    def custom_stoploss(self, pair: str, trade: Trade, current_time: datetime, current_rate: float,
                    current_profit: float, **kwargs) -> Optional[float]:
        return self.risk_module.adjust_stoploss(pair, trade, current_time, current_rate, current_profit, **kwargs)

    def _get_signal_param_sets(self, signals):
        if hasattr(self, 'ft_params') and isinstance(self.ft_params, dict):
            return [
                {k: v for k, v in self.ft_params.items()
                 if k.startswith(sig.__class__.__name__[:6].lower())}
                for sig in signals
            ]
        return [{} for _ in signals]
